"""Adaptador relacional de TurnoLab."""
